package mypackage;

import java.awt.geom.Area;
import java.text.DecimalFormat;
import java.util.Scanner;

import mypackage.Circle;

public class Main {
    private static DecimalFormat formater = new DecimalFormat("#.##");
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {


        int choice = -1;

        /*
        this menu loop while choice isn't equals to 0, and I put it as -1, so it doesn't do anything that we don't want
        this part opens the menu where the user can choose whatever
         */
        //Menu with choice and while loop!
        while (choice != 0) {
            showMenu();
            choice = sc.nextInt();
            sc.nextLine();
            runMenu(choice);
        }
    }

    // The menu
    public static void showMenu() {
        System.out.println(" which gemometrical shape do you want to calculate?");
        System.out.println();
        System.out.println("1. Circle");
        System.out.println("2. Square");
        System.out.println("3. Triangle");
        System.out.println("4. Rectangle");
        System.out.println("0. Exit");
        System.out.println("\nMake your choice?");

    }

    /*
    This is the 4 choices the user can make every choice has one method in this class and an own class that I created!
     */
    public static void runMenu(int choice) {
        if (choice == 1) {
            CircleCalculations();
        } else if (choice == 2) {
            squareCalculations();
        } else if (choice == 3) {
            triangleCalculator();
        } else if (choice ==4) {
            rectangleCalculations();
        }
    }




    public static void CircleCalculations() {
        System.out.println("Enter circle radius");
        double radius = sc.nextDouble();
        Circle c = new Circle(radius); // this part I used the reference for the circle
        c.setRadius(radius); // here I used the Circles setRadius method because the value must be set because the user choose to set their own value of the radius
        // same here i used a reference from the Circle.java class but from the Area method and same with the perimeter method from Circle.java class
        System.out.println("Area of the circle is: " + formater.format(c.area()) + " and the omkrets is: " + formater.format(c.perimeter()));
    }


    public static void squareCalculations() {
        System.out.println("Enter Height/Length");
        int side = sc.nextInt();
        Square s = new Square(side);
        s.setSide(side);
        System.out.println("the AREA is ------> : " + s.area() + " and the PERIMETER is :) ----> : " + s.perimeter());
    }

    public static void triangleCalculator() {
        System.out.println("Enter side 1");
        double side1 = sc.nextInt();
        System.out.println("Enter side 2");
        double side2 = sc.nextInt();
        System.out.println("Enter Base");
        double base = sc.nextInt();
        System.out.println("Enter Height");
        double height = sc.nextInt();
        sc.nextLine();
        Triangle t = new Triangle(base, height, side1, side2);
        System.out.println("Area of the circle is: " + (t.area()) + " and the omkrets is: " + (t.perimeter()));
    }

    private static void rectangleCalculations() {
        System.out.println("Enter side 1");
        double side1 = sc.nextDouble();
        System.out.println("Enter side 2");
        double side2 = sc.nextDouble();
        sc.nextLine();
        Rectangle rc = new Rectangle(side1, side2);
        System.out.println("Area of the rectangle is: "+rc.area()+" and the perimeter is: "+rc.perimeter());
    }


}

/*
in this program i have used classes, objects, constructors and, getters and setters
Setter: a Setter is updates a value, in the setter method you can directly set a object reference
you can create two references and links to one object!


Getter: Reads the value from a variable. The getter method returns the reference
of the object directly!, anyone can use this reference from the outside code to change

for example:
private MainEx Teacher({
return this.teacher;

Teacher teach1 = getTeacher();
teach1.setAge(23);
}



Constructor:
constructor is a method that is used to initalize a new created object
 and is called after the memory is allocated
 */
