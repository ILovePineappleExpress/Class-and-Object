package mypackage;

import mypackage.Main;

public class Circle {
    //Private means that the methods can only be modified using this class (Circle.java) and if it were public any class could acess it and modify it and that
    // we dont want

    private double radius;

    private static final double PI = 3.14; // final is something that is constant value

    public Circle(double radius) {
        this.radius = radius;
    }

    public double area() {
        return radius * radius * PI;
    }



    public double getRadius(double radius) {
        return radius;
    }



    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double perimeter() {
        return (radius + radius) * PI;
    }


}
