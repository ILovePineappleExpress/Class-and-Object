package mypackage;

public class Square {
    private int side;

    public Square(int side) {
        this.side = side;

    }

    public double area() {
        return side*side;
    }

    public int perimeter(){
        return side*4;
    }

    public int getSide() {
        return side;
    }

    public void setSide(int side) {
        this.side = side;
    }


    public void setLength(int side) {
        this.side = side;
    }
}
